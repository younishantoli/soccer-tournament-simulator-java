package groupprojectsoccer;

public interface Simulatable {
	void simulateMatch();
}
/*
 * Interface; whatever is 'Simulatable' has to implement simulateMatch()
 */
